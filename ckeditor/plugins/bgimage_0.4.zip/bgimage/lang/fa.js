CKEDITOR.plugins.setLang('bgimage','fa',{
	bgImageTitle : 'تصویر پس زمینه',
	imageUrl     : 'آدرس عکس',
	repeat	     : 'تکرار',
	attachment   : 'ضمیمه',
	blendMode    : 'حالت لایه',
	position	 : 'موقعیت',
	bgWidth    : '(eg : 20px) عرض',
	bgHeight   : '(eg : 20px) ارتفاع'
})
